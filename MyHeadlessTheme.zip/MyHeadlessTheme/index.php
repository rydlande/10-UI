<?php
$mysite = "<link to your Netlify-page or similar>";
header('Location: '.$mysite);
exit();
?>